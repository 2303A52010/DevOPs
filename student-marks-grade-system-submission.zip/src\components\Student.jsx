import React from 'react';

/**
 * Student Component
 * Displays student information received directly via PROPS:
 * - studentId
 * - studentName
 * - department
 * - subjectNames
 * - marks
 */
export default function Student({ studentId, studentName, department, subjectNames = [], marks = {} }) {
  if (!studentId) {
    return (
      <div className="card student-card empty-card">
        <p>Please select a student to view details.</p>
      </div>
    );
  }

  // Calculate quick metrics for student card
  const markList = subjectNames.map((subj) => Number(marks[subj] ?? 0));
  const total = markList.reduce((acc, curr) => acc + curr, 0);
  const maxMarks = subjectNames.length * 100;
  const percentage = subjectNames.length > 0 ? (total / subjectNames.length).toFixed(1) : 0;

  return (
    <div className="card student-card">
      <div className="student-profile-header">
        <div className="student-avatar">
          {studentName
            .split(' ')
            .map((n) => n[0])
            .slice(0, 2)
            .join('')}
        </div>
        <div className="student-meta">
          <div className="student-id-tag">ID: {studentId}</div>
          <h2 className="student-name">{studentName}</h2>
          <p className="student-department">
            <span className="dept-icon">🏛️</span> {department}
          </p>
        </div>
        <div className="profile-badge-group">
          <div className="profile-stat-box">
            <span className="profile-stat-number">{percentage}%</span>
            <span className="profile-stat-label">Aggregate</span>
          </div>
          <div className="profile-stat-box">
            <span className="profile-stat-number">{total} / {maxMarks}</span>
            <span className="profile-stat-label">Total Marks</span>
          </div>
        </div>
      </div>

      <div className="student-subjects-section">
        <div className="section-title-row">
          <h4>Enrolled Subjects & Current Marks</h4>
          <span className="subject-count-pill">{subjectNames.length} Subjects</span>
        </div>

        <div className="subject-cards-grid">
          {subjectNames.map((subject) => {
            const mark = Number(marks[subject] ?? 0);
            const isGood = mark >= 75;
            const isPass = mark >= 40;

            return (
              <div key={subject} className={`subject-item-card ${isPass ? 'pass-border' : 'fail-border'}`}>
                <div className="subject-card-top">
                  <span className="subject-title">{subject}</span>
                  <span className={`subject-mark-badge ${isGood ? 'high-score' : isPass ? 'avg-score' : 'low-score'}`}>
                    {mark} / 100
                  </span>
                </div>
                <div className="subject-progress-bg">
                  <div
                    className={`subject-progress-fill ${isGood ? 'bg-green' : isPass ? 'bg-blue' : 'bg-red'}`}
                    style={{ width: `${Math.min(mark, 100)}%` }}
                  ></div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
