import React from 'react';
import Grade from './Grade';

/**
 * Result Component
 * Demonstrates:
 * - Total marks calculation
 * - Average marks / percentage calculation
 * - Pass/Fail determination
 * - Embedding Grade component with conditional styling
 */
export default function Result({ student }) {
  if (!student) {
    return (
      <div className="result-card empty-card">
        <p>No student selected for evaluation.</p>
      </div>
    );
  }

  const subjectNames = Object.keys(student.marks || {});
  const markValues = Object.values(student.marks || {});
  const totalSubjects = subjectNames.length;

  // Total Marks Calculation
  const totalMarks = markValues.reduce((sum, mark) => sum + Number(mark), 0);
  const maxMarks = totalSubjects * 100;

  // Average Marks Calculation
  const averageMarks = totalSubjects > 0 ? (totalMarks / totalSubjects) : 0;
  const roundedAverage = Number(averageMarks.toFixed(2));

  // Pass/Fail Determination
  // A student passes if every subject has >= 40 marks and overall average >= 50%
  const hasFailedAnySubject = markValues.some((mark) => Number(mark) < 40);
  const isPassed = !hasFailedAnySubject && roundedAverage >= 50;

  return (
    <div className="card result-card">
      <div className="card-header">
        <div className="header-title-group">
          <span className="card-icon">📊</span>
          <div>
            <h3>Academic Performance & Result</h3>
            <p className="subtitle">Consolidated evaluation for {student.name} ({student.id})</p>
          </div>
        </div>

        {/* Pass/Fail Status Badge */}
        <div className={`status-pill ${isPassed ? 'status-pass' : 'status-fail'}`}>
          <span className="status-dot"></span>
          {isPassed ? 'PASSED' : 'FAILED'}
        </div>
      </div>

      <div className="metrics-grid">
        <div className="metric-box">
          <span className="metric-label">Total Marks</span>
          <div className="metric-value-row">
            <span className="metric-value">{totalMarks}</span>
            <span className="metric-total">/ {maxMarks}</span>
          </div>
          <div className="progress-bar-bg">
            <div
              className="progress-bar-fill fill-blue"
              style={{ width: `${maxMarks > 0 ? (totalMarks / maxMarks) * 100 : 0}%` }}
            ></div>
          </div>
        </div>

        <div className="metric-box">
          <span className="metric-label">Average Score</span>
          <div className="metric-value-row">
            <span className="metric-value">{roundedAverage}%</span>
            <span className="metric-total">50% req.</span>
          </div>
          <div className="progress-bar-bg">
            <div
              className={`progress-bar-fill ${roundedAverage >= 75 ? 'fill-green' : roundedAverage >= 50 ? 'fill-blue' : 'fill-red'}`}
              style={{ width: `${Math.min(roundedAverage, 100)}%` }}
            ></div>
          </div>
        </div>

        <div className="metric-box">
          <span className="metric-label">Subject Status</span>
          <div className="metric-value-row">
            <span className="metric-value">
              {markValues.filter((m) => Number(m) >= 40).length} / {totalSubjects}
            </span>
            <span className="metric-total">Passed</span>
          </div>
          <p className="metric-subtext">Min. passing mark: 40/100</p>
        </div>
      </div>

      {/* Embedded Grade Component with Conditional Rendering */}
      <Grade average={roundedAverage} isPassed={isPassed} />

      {/* Subject-Wise Summary Table */}
      <div className="subject-breakdown-section">
        <h4>Subject Evaluation Summary</h4>
        <div className="breakdown-table-wrapper">
          <table className="breakdown-table">
            <thead>
              <tr>
                <th>Subject</th>
                <th>Marks Obtained</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {subjectNames.map((subject) => {
                const mark = Number(student.marks[subject]);
                const subPassed = mark >= 40;
                return (
                  <tr key={subject} className={subPassed ? 'row-pass' : 'row-fail'}>
                    <td className="subject-name-cell">{subject}</td>
                    <td>
                      <div className="table-mark-cell">
                        <strong>{mark}</strong>
                        <span className="mark-max">/ 100</span>
                      </div>
                    </td>
                    <td>
                      <span className={`badge ${subPassed ? 'badge-pass' : 'badge-fail'}`}>
                        {subPassed ? 'Clear' : 'Arrear'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
