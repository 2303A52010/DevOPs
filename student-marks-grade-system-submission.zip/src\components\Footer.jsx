import React from 'react';

/**
 * Footer Component
 */
export default function Footer() {
  return (
    <footer className="app-footer">
      <div className="footer-content">
        <p className="copyright-text">
          © 2026 School of Computer Science Engineering & AI — Department of DevOps & Full Stack Web Development
        </p>
        <p className="tech-stack-text">
          Built with React 19 + Vite • Demonstrating Props, React State (<code>useState</code>), Form Validation & Conditional Rendering
        </p>
      </div>
    </footer>
  );
}
