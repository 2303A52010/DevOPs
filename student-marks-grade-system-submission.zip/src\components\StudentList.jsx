import React from 'react';

/**
 * StudentList Component
 * Demonstrates:
 * - Displaying a roster of students
 * - Selecting an active student
 * - Bonus: Search students by name (case-insensitive)
 * - Quick badges for student status
 */
export default function StudentList({
  students,
  selectedStudentId,
  onSelectStudent,
  searchQuery,
  onSearchChange,
}) {
  // Filter students by search term (Bonus Challenge)
  const filteredStudents = students.filter((student) =>
    student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    student.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
    student.department.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="card student-list-card">
      <div className="student-list-header">
        <div className="list-title-badge">
          <h3>Student Directory</h3>
          <span className="count-tag">{filteredStudents.length} / {students.length}</span>
        </div>

        {/* Bonus Challenge: Search students by name */}
        <div className="search-box">
          <span className="search-icon">🔍</span>
          <input
            type="text"
            className="search-input"
            placeholder="Search student by name or ID..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
          />
          {searchQuery && (
            <button
              className="clear-search-btn"
              onClick={() => onSearchChange('')}
              title="Clear search"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      <div className="student-items-list">
        {filteredStudents.length === 0 ? (
          <div className="no-students-found">
            <span className="no-results-icon">🔎</span>
            <p>No students match "<strong>{searchQuery}</strong>"</p>
            <button className="btn btn-secondary btn-sm" onClick={() => onSearchChange('')}>
              Reset Search Filter
            </button>
          </div>
        ) : (
          filteredStudents.map((student) => {
            const isSelected = student.id === selectedStudentId;
            const marksList = Object.values(student.marks || {});
            const total = marksList.reduce((sum, val) => sum + Number(val), 0);
            const avg = marksList.length > 0 ? (total / marksList.length).toFixed(1) : 0;
            const hasFail = marksList.some((m) => Number(m) < 40);
            const isPass = !hasFail && avg >= 50;

            return (
              <div
                key={student.id}
                role="button"
                tabIndex={0}
                className={`student-list-item ${isSelected ? 'active-student' : ''}`}
                onClick={() => onSelectStudent(student.id)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    onSelectStudent(student.id);
                  }
                }}
              >
                <div className="item-left">
                  <div className="avatar-chip">
                    {student.name
                      .split(' ')
                      .map((n) => n[0])
                      .slice(0, 2)
                      .join('')}
                  </div>
                  <div className="item-text">
                    <div className="item-name-row">
                      <h4 className="item-name">{student.name}</h4>
                      {isSelected && <span className="selected-tag">Selected</span>}
                    </div>
                    <span className="item-id">{student.id} • {student.department}</span>
                  </div>
                </div>

                <div className="item-right">
                  <span className="item-avg">{avg}%</span>
                  <span className={`status-micro-pill ${isPass ? 'micro-pass' : 'micro-fail'}`}>
                    {isPass ? 'PASS' : 'FAIL'}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
