import React, { useState } from 'react';
import Header from './components/Header';
import ClassStats from './components/ClassStats';
import StudentList from './components/StudentList';
import Student from './components/Student';
import MarksForm from './components/MarksForm';
import Result from './components/Result';
import Footer from './components/Footer';
import './App.css';

// Default initial student data with realistic marks across 5 technical subjects
const INITIAL_STUDENTS = [
  {
    id: '23CS101',
    name: 'Aarav Sharma',
    department: 'Computer Science and Engineering',
    marks: {
      'DevOps Tools & CI/CD': 88,
      'Full Stack Web Development': 92,
      'Cloud Computing & AWS': 85,
      'Data Structures & Algorithms': 90,
      'AI & Machine Learning': 84,
    },
  },
  {
    id: '23CS102',
    name: 'Priya Patel',
    department: 'Artificial Intelligence & Machine Learning',
    marks: {
      'DevOps Tools & CI/CD': 95,
      'Full Stack Web Development': 94,
      'Cloud Computing & AWS': 98,
      'Data Structures & Algorithms': 92,
      'AI & Machine Learning': 96,
    },
  },
  {
    id: '23CS103',
    name: 'Rahul Verma',
    department: 'Computer Science and Engineering',
    marks: {
      'DevOps Tools & CI/CD': 55,
      'Full Stack Web Development': 62,
      'Cloud Computing & AWS': 58,
      'Data Structures & Algorithms': 64,
      'AI & Machine Learning': 52,
    },
  },
  {
    id: '23CS104',
    name: 'Ananya Reddy',
    department: 'Data Science & Analytics',
    marks: {
      'DevOps Tools & CI/CD': 74,
      'Full Stack Web Development': 78,
      'Cloud Computing & AWS': 80,
      'Data Structures & Algorithms': 68,
      'AI & Machine Learning': 75,
    },
  },
  {
    id: '23CS105',
    name: 'Vikram Singh',
    department: 'Computer Science and Engineering',
    marks: {
      'DevOps Tools & CI/CD': 65,
      'Full Stack Web Development': 58,
      'Cloud Computing & AWS': 34, // Failed subject (<40)
      'Data Structures & Algorithms': 45,
      'AI & Machine Learning': 50,
    },
  },
  {
    id: '23CS106',
    name: 'Sneha Kulkarni',
    department: 'Information Technology',
    marks: {
      'DevOps Tools & CI/CD': 82,
      'Full Stack Web Development': 86,
      'Cloud Computing & AWS': 79,
      'Data Structures & Algorithms': 88,
      'AI & Machine Learning': 85,
    },
  },
];

export default function App() {
  // STATE MANAGEMENT using useState():
  // 1. Store student details and marks
  const [students, setStudents] = useState(INITIAL_STUDENTS);

  // 2. Track selected student for viewing and editing
  const [selectedStudentId, setSelectedStudentId] = useState('23CS101');

  // 3. Search query state for student filtering (Bonus)
  const [searchQuery, setSearchQuery] = useState('');

  // 4. Active tab inside the management panel
  const [activeTab, setActiveTab] = useState('result'); // 'result' | 'edit'

  // Locate the currently selected student
  const selectedStudent =
    students.find((s) => s.id === selectedStudentId) || students[0];

  // Extract subject names list for props passing
  const subjectNames = selectedStudent
    ? Object.keys(selectedStudent.marks || {})
    : [];

  // Update marks handler passed down to MarksForm
  const handleUpdateMarks = (studentId, updatedMarks) => {
    setStudents((prevStudents) =>
      prevStudents.map((stud) =>
        stud.id === studentId ? { ...stud, marks: updatedMarks } : stud
      )
    );
  };

  return (
    <div className="app-layout">
      {/* College Header */}
      <Header />

      <main className="main-content">
        {/* Bonus Challenge: Real-time Class Aggregate Statistics */}
        <ClassStats students={students} />

        <div className="dashboard-grid">
          {/* Left Column: Student Directory & Search */}
          <aside className="sidebar-column">
            <StudentList
              students={students}
              selectedStudentId={selectedStudentId}
              onSelectStudent={(id) => {
                setSelectedStudentId(id);
              }}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
            />
          </aside>

          {/* Right Column: Student Profile, Marks Form & Evaluation Result */}
          <section className="detail-column">
            {/* Component: Student (Demonstrating Props passing) */}
            <Student
              studentId={selectedStudent?.id}
              studentName={selectedStudent?.name}
              department={selectedStudent?.department}
              subjectNames={subjectNames}
              marks={selectedStudent?.marks}
            />

            {/* Tab Navigation for Faculty: Result Analysis vs Marks Entry */}
            <div className="panel-tabs">
              <button
                className={`tab-button ${activeTab === 'result' ? 'active' : ''}`}
                onClick={() => setActiveTab('result')}
              >
                📊 Results & Grade Assessment
              </button>
              <button
                className={`tab-button ${activeTab === 'edit' ? 'active' : ''}`}
                onClick={() => setActiveTab('edit')}
              >
                ✏️ Faculty Marks Entry / Edit Form
              </button>
            </div>

            {/* Conditional Rendering of active view */}
            {activeTab === 'result' ? (
              <Result student={selectedStudent} />
            ) : (
              <MarksForm
                key={selectedStudent?.id}
                student={selectedStudent}
                onUpdateMarks={handleUpdateMarks}
              />
            )}
          </section>
        </div>
      </main>

      {/* College Footer */}
      <Footer />
    </div>
  );
}
