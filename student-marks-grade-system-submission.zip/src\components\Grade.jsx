import React from 'react';

/**
 * Grade Component
 * Demonstrates:
 * - Grade determination based on average marks & pass/fail status
 * - Conditional rendering based on grade tier
 */
export default function Grade({ average, isPassed }) {
  // Determine Grade
  let gradeCode = 'F';
  let gradeTitle = 'Fail';
  let gpa = 0.0;
  let remark = 'Requires immediate improvement & remedial examination.';
  let themeClass = 'grade-fail';

  if (isPassed) {
    if (average >= 90) {
      gradeCode = 'O';
      gradeTitle = 'Outstanding';
      gpa = 10.0;
      remark = 'Exemplary academic mastery and exceptional achievement!';
      themeClass = 'grade-outstanding';
    } else if (average >= 80) {
      gradeCode = 'A+';
      gradeTitle = 'Excellent';
      gpa = 9.0;
      remark = 'Consistently superior academic performance across all subjects.';
      themeClass = 'grade-excellent';
    } else if (average >= 70) {
      gradeCode = 'A';
      gradeTitle = 'Very Good';
      gpa = 8.0;
      remark = 'Commendable effort and solid grasp of technical coursework.';
      themeClass = 'grade-verygood';
    } else if (average >= 60) {
      gradeCode = 'B+';
      gradeTitle = 'Good';
      gpa = 7.0;
      remark = 'Satisfactory competency with good foundational knowledge.';
      themeClass = 'grade-good';
    } else if (average >= 50) {
      gradeCode = 'B';
      gradeTitle = 'Above Average';
      gpa = 6.0;
      remark = 'Meets standard passing requirements; scope for technical enhancement.';
      themeClass = 'grade-average';
    }
  }

  return (
    <div className={`grade-container ${themeClass}`}>
      <div className="grade-header">
        <span className="grade-tag">Final Academic Grade</span>
        <span className="gpa-badge">Grade Point: {gpa.toFixed(1)} / 10.0</span>
      </div>

      {/* Conditional Rendering of Grade Badge and Details */}
      <div className="grade-body">
        <div className="grade-badge-circle">
          <span className="grade-letter">{gradeCode}</span>
        </div>
        <div className="grade-details">
          <h4 className="grade-title">{gradeTitle}</h4>
          <p className="grade-remark">{remark}</p>
        </div>
      </div>

      {/* Conditional Rendering for Honors / Warning Notes */}
      <div className="grade-footer">
        {gradeCode === 'O' && (
          <div className="conditional-banner banner-gold">
            🏆 <strong>Dean's Honor List</strong> - Recommended for academic excellence award.
          </div>
        )}

        {(gradeCode === 'A+' || gradeCode === 'A') && (
          <div className="conditional-banner banner-blue">
            ⭐ <strong>First Class with Distinction</strong> - Eligible for merit placement assistance.
          </div>
        )}

        {(gradeCode === 'B+' || gradeCode === 'B') && (
          <div className="conditional-banner banner-amber">
            📘 <strong>First Class</strong> - Eligible for standard semester progression.
          </div>
        )}

        {gradeCode === 'F' && (
          <div className="conditional-banner banner-red">
            ⚠️ <strong>Academic Warning</strong> - Student must register for remedial supplementary assessments.
          </div>
        )}
      </div>
    </div>
  );
}
