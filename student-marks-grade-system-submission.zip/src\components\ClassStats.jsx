import React from 'react';

/**
 * ClassStats Component (Bonus Challenge)
 * Calculates and displays:
 * - Class average mark
 * - Total students enrolled
 * - Total passed & failed students
 * - Top performer in class
 */
export default function ClassStats({ students }) {
  if (!students || students.length === 0) return null;

  const totalStudents = students.length;

  let totalAggregateMarks = 0;
  let totalPossibleMarks = 0;
  let passedCount = 0;
  let topStudent = null;
  let highestAverage = -1;

  students.forEach((student) => {
    const marks = Object.values(student.marks || {}).map(Number);
    const studentTotal = marks.reduce((sum, m) => sum + m, 0);
    const studentAvg = marks.length > 0 ? studentTotal / marks.length : 0;
    const hasFailedSubject = marks.some((m) => m < 40);
    const isPassed = !hasFailedSubject && studentAvg >= 50;

    if (isPassed) passedCount += 1;

    totalAggregateMarks += studentTotal;
    totalPossibleMarks += marks.length * 100;

    if (studentAvg > highestAverage) {
      highestAverage = studentAvg;
      topStudent = {
        name: student.name,
        id: student.id,
        average: studentAvg.toFixed(1),
      };
    }
  });

  const classAverage =
    totalPossibleMarks > 0 ? ((totalAggregateMarks / totalPossibleMarks) * 100).toFixed(1) : 0;
  const failedCount = totalStudents - passedCount;
  const passRate = totalStudents > 0 ? ((passedCount / totalStudents) * 100).toFixed(0) : 0;

  return (
    <section className="class-stats-banner">
      <div className="stats-card">
        <div className="stat-icon-wrapper icon-blue">👥</div>
        <div className="stat-info">
          <span className="stat-label">Total Enrolled</span>
          <span className="stat-value">{totalStudents} Students</span>
        </div>
      </div>

      <div className="stats-card">
        <div className="stat-icon-wrapper icon-indigo">📈</div>
        <div className="stat-info">
          <span className="stat-label">Class Average</span>
          <span className="stat-value">{classAverage}%</span>
        </div>
      </div>

      <div className="stats-card">
        <div className="stat-icon-wrapper icon-green">🏆</div>
        <div className="stat-info">
          <span className="stat-label">Passed / Pass Rate</span>
          <span className="stat-value">
            {passedCount} <small className="stat-sub">({passRate}%)</small>
          </span>
        </div>
      </div>

      <div className="stats-card">
        <div className="stat-icon-wrapper icon-amber">⚠️</div>
        <div className="stat-info">
          <span className="stat-label">Arrears / Remedial</span>
          <span className="stat-value">{failedCount} Students</span>
        </div>
      </div>

      {topStudent && (
        <div className="stats-card stat-top-card">
          <div className="stat-icon-wrapper icon-gold">⭐</div>
          <div className="stat-info">
            <span className="stat-label">Batch Top Scorer</span>
            <span className="stat-value">{topStudent.name}</span>
            <span className="stat-extra">{topStudent.average}% ({topStudent.id})</span>
          </div>
        </div>
      )}
    </section>
  );
}
