import React, { useState } from 'react';

/**
 * MarksForm Component
 * Allows faculty members to enter/update marks for different subjects.
 * Includes:
 * - Controlled inputs with useState()
 * - Bonus: Real-time validation for marks between 0 and 100
 * - Field-level error messages
 * - Reset and Quick preset tools
 */
export default function MarksForm({ student, onUpdateMarks }) {
  // Local form state initialized directly for the student
  const [formMarks, setFormMarks] = useState(() => (student?.marks ? { ...student.marks } : {}));
  const [errors, setErrors] = useState({});
  const [isSaved, setIsSaved] = useState(false);

  if (!student) {
    return null;
  }

  const subjectNames = Object.keys(student.marks || {});

  // Validation function: checks if mark is between 0 and 100
  const validateMark = (value) => {
    if (value === '' || value === null || value === undefined) {
      return 'Mark cannot be empty';
    }
    const num = Number(value);
    if (isNaN(num)) {
      return 'Must be a valid numeric value';
    }
    if (num < 0) {
      return 'Marks cannot be negative (min: 0)';
    }
    if (num > 100) {
      return 'Marks cannot exceed 100 (max: 100)';
    }
    return null;
  };

  // Handle individual subject input change
  const handleChange = (subject, value) => {
    const error = validateMark(value);

    setFormMarks((prev) => ({
      ...prev,
      [subject]: value,
    }));

    setErrors((prev) => {
      const updated = { ...prev };
      if (error) {
        updated[subject] = error;
      } else {
        delete updated[subject];
      }
      return updated;
    });

    setIsSaved(false);
  };

  // Check if any errors exist or any field is empty
  const hasErrors = Object.keys(errors).length > 0;
  const isFormComplete = subjectNames.every(
    (subj) => formMarks[subj] !== '' && formMarks[subj] !== undefined && !errors[subj]
  );

  // Handle Form Submission
  const handleSubmit = (e) => {
    e.preventDefault();

    // Re-validate all fields on submit
    const currentErrors = {};
    const sanitizedMarks = {};

    subjectNames.forEach((subj) => {
      const val = formMarks[subj];
      const err = validateMark(val);
      if (err) {
        currentErrors[subj] = err;
      } else {
        sanitizedMarks[subj] = Number(val);
      }
    });

    if (Object.keys(currentErrors).length > 0) {
      setErrors(currentErrors);
      return;
    }

    // Call parent handler to update student marks in global state
    onUpdateMarks(student.id, sanitizedMarks);
    setIsSaved(true);

    // Auto-dismiss save feedback after 3 seconds
    setTimeout(() => {
      setIsSaved(false);
    }, 3000);
  };

  // Preset action handlers for faculty convenience
  const handleSetPreset = (targetScore) => {
    const presetMarks = {};
    subjectNames.forEach((subj) => {
      presetMarks[subj] = targetScore;
    });
    setFormMarks(presetMarks);
    setErrors({});
    setIsSaved(false);
  };

  const handleResetToCurrent = () => {
    if (student && student.marks) {
      setFormMarks({ ...student.marks });
      setErrors({});
      setIsSaved(false);
    }
  };

  return (
    <div className="card form-card">
      <div className="card-header">
        <div className="header-title-group">
          <span className="card-icon">✏️</span>
          <div>
            <h3>Faculty Marks Entry Portal</h3>
            <p className="subtitle">Enter or modify subject marks for {student.name}</p>
          </div>
        </div>

        <div className="form-quick-actions">
          <button
            type="button"
            className="btn-text-action"
            onClick={() => handleSetPreset(85)}
            title="Set all subjects to 85"
          >
            Set 85
          </button>
          <button
            type="button"
            className="btn-text-action"
            onClick={() => handleSetPreset(45)}
            title="Set all subjects to 45 (Borderline Pass)"
          >
            Set 45
          </button>
          <button
            type="button"
            className="btn-text-action"
            onClick={handleResetToCurrent}
            title="Reset to current stored marks"
          >
            Reset
          </button>
        </div>
      </div>

      {isSaved && (
        <div className="alert-banner alert-success">
          ✅ <strong>Marks Updated!</strong> Successfully recorded marks for {student.name} in state.
        </div>
      )}

      <form onSubmit={handleSubmit} className="marks-input-form" noValidate>
        <div className="marks-input-grid">
          {subjectNames.map((subject) => {
            const hasError = Boolean(errors[subject]);
            const val = formMarks[subject] ?? '';

            return (
              <div key={subject} className={`form-group ${hasError ? 'has-error' : ''}`}>
                <label htmlFor={`input-${subject}`} className="form-label">
                  {subject}
                  <span className="scale-hint">(0 - 100)</span>
                </label>

                <div className="input-wrapper">
                  <input
                    id={`input-${subject}`}
                    type="number"
                    min="0"
                    max="100"
                    value={val}
                    onChange={(e) => handleChange(subject, e.target.value)}
                    className={`form-input ${hasError ? 'input-invalid' : ''}`}
                    placeholder="Enter mark (0-100)"
                  />
                  <span className="input-suffix">/ 100</span>
                </div>

                {hasError && <div className="error-message">⚠️ {errors[subject]}</div>}
              </div>
            );
          })}
        </div>

        <div className="form-submit-row">
          <div className="validation-status-text">
            {hasErrors ? (
              <span className="text-danger">⚠️ Correct the validation errors above before saving.</span>
            ) : (
              <span className="text-muted">All entered marks are validated (0–100 scale).</span>
            )}
          </div>

          <button
            type="submit"
            className="btn btn-primary"
            disabled={hasErrors || !isFormComplete}
          >
            💾 Save & Update Marks
          </button>
        </div>
      </form>
    </div>
  );
}
