import React from 'react';

/**
 * Header Component
 * Contains college metadata, course credentials, instructors, and lab assignment info
 */
export default function Header() {
  return (
    <header className="app-header">
      <div className="header-container">
        <div className="header-brand">
          <div className="college-logo">🎓</div>
          <div className="brand-text">
            <span className="institution-name">
              School of Computer Science Engineering and Artificial Intelligence
            </span>
            <h1 className="system-title">Student Marks & Grade Management System</h1>
            <div className="course-badges-row">
              <span className="badge-tag tag-primary">Course: B.Tech (Professional Elective)</span>
              <span className="badge-tag tag-secondary">Code: 23CS102PE405</span>
              <span className="badge-tag tag-accent">DEVOPS AND FULLSTACK</span>
              <span className="badge-tag tag-date">Lab Experiment Week-6.2</span>
            </div>
          </div>
        </div>

        <div className="faculty-card">
          <div className="faculty-title">Faculty Instructors</div>
          <p className="faculty-names">
            Dr. Mohammed Ali Shaik • Dr. N. Venkatesh • Mr. Kranthi • Srivani
          </p>
          <div className="term-info">Year: 2026–27 | Semester: ODD | Date: 10.09.2026</div>
        </div>
      </div>
    </header>
  );
}
