import React from 'react';

function SubjectList({ subjects = [] }) {
  return (
    <div className="card subject-list-card">
      <div className="card-header">
        <h2 className="card-title">📚 Enrolled Subjects</h2>
        <span className="card-count">{subjects.length} Courses</span>
      </div>
      {subjects.length === 0 ? (
        <p className="empty-notice">No subjects assigned.</p>
      ) : (
        <div className="table-responsive">
          <table className="subjects-table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Subject Name</th>
                <th>Faculty</th>
                <th>Credits</th>
                <th>Type</th>
              </tr>
            </thead>
            <tbody>
              {subjects.map((subject, index) => (
                <tr key={subject.code || index}>
                  <td className="code-badge">{subject.code}</td>
                  <td className="subject-name">{subject.name}</td>
                  <td>{subject.instructor || 'Faculty Member'}</td>
                  <td><span className="credit-pill">{subject.credits} Credits</span></td>
                  <td><span className={`type-tag tag-${(subject.type || 'core').toLowerCase()}`}>{subject.type || 'Core'}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default SubjectList;
