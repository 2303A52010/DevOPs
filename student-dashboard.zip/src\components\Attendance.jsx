import React from 'react';

function Attendance({ percentage = 0, attendedClasses, totalClasses }) {
  // Threshold for eligibility is 75%
  const isEligible = percentage >= 75;

  return (
    <div className="card attendance-card">
      <div className="card-header">
        <h2 className="card-title">📊 Attendance Overview</h2>
        <span className={`status-pill ${isEligible ? 'status-eligible' : 'status-not-eligible'}`}>
          {isEligible ? '✓ Eligible' : '✗ Not Eligible'}
        </span>
      </div>

      <div className="attendance-body">
        <div className="attendance-metric">
          <div className="metric-number-wrapper">
            <span className={`metric-number ${isEligible ? 'text-success' : 'text-danger'}`}>
              {percentage}%
            </span>
            <span className="metric-subtitle">Overall Attendance</span>
          </div>

          <div className="progress-bar-container">
            <div
              className={`progress-bar-fill ${isEligible ? 'fill-success' : 'fill-danger'}`}
              style={{ width: `${Math.min(Math.max(percentage, 0), 100)}%` }}
            ></div>
          </div>
          <div className="threshold-marker">
            <span>0%</span>
            <span className="req-label">75% Required</span>
            <span>100%</span>
          </div>
        </div>

        {attendedClasses !== undefined && totalClasses !== undefined && (
          <div className="attendance-stats">
            <div className="stat-box">
              <span className="stat-label">Classes Attended</span>
              <span className="stat-count">{attendedClasses}</span>
            </div>
            <div className="stat-box">
              <span className="stat-label">Total Conducted</span>
              <span className="stat-count">{totalClasses}</span>
            </div>
          </div>
        )}

        {/* Conditional Rendering for Examination Eligibility */}
        <div className={`eligibility-notice ${isEligible ? 'notice-success' : 'notice-danger'}`}>
          {isEligible ? (
            <p>
              🎉 <strong>Exam Status: Eligible</strong> — You have satisfied the minimum attendance criterion ($\ge 75\%$) for the upcoming semester examinations.
            </p>
          ) : (
            <p>
              ⚠️ <strong>Exam Status: Not Eligible</strong> — Your attendance is below the mandatory 75% requirement. Please consult your academic advisor.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

export default Attendance;
