import React, { useState } from 'react';
import Header from './components/Header';
import StudentProfile from './components/StudentProfile';
import SubjectList from './components/SubjectList';
import Attendance from './components/Attendance';
import ExamDetails from './components/ExamDetails';
import StudentCard from './components/StudentCard';
import Footer from './components/Footer';
import './dashboard.css';

// Mock student datasets to showcase reusable components and dynamic props
const STUDENTS_DATA = [
  {
    id: 1,
    name: "Aarav Sharma",
    rollNumber: "23CS102PE-045",
    branch: "Computer Science & Engineering (AI)",
    year: "3rd Year (B.Tech)",
    section: "CSE-AI A",
    email: "aarav.sharma@scse.edu",
    attendance: 86,
    attendedClasses: 129,
    totalClasses: 150,
    hallTicketStatus: "Issued",
    subjects: [
      { code: "23CS102PE405", name: "DevOps and Fullstack", instructor: "Dr. Mohammed Ali Shaik", credits: 4, type: "Core" },
      { code: "23CS102PC401", name: "Deep Learning & Neural Networks", instructor: "Dr. N. Venkatesh", credits: 4, type: "Core" },
      { code: "23CS102PE408", name: "Cloud Infrastructure & Containers", instructor: "Mr. G. Kranthi", credits: 3, type: "Elective" },
      { code: "23CS102PC402", name: "Natural Language Processing", instructor: "Mrs. Sri Vani", credits: 3, type: "Core" },
      { code: "23CS102PL403", name: "Fullstack Development Laboratory", instructor: "Faculty Team", credits: 1.5, type: "Lab" }
    ],
    exams: [
      { code: "23CS102PE405", subject: "DevOps and Fullstack", date: "17.09.2026", session: "FN (09:30 AM - 12:30 PM)", time: "3 Hours", venue: "Academic Block B - Hall 204" },
      { code: "23CS102PC401", subject: "Deep Learning & Neural Networks", date: "21.09.2026", session: "FN (09:30 AM - 12:30 PM)", time: "3 Hours", venue: "Academic Block B - Hall 204" },
      { code: "23CS102PE408", subject: "Cloud Infrastructure & Containers", date: "24.09.2026", session: "FN (09:30 AM - 12:30 PM)", time: "3 Hours", venue: "Academic Block B - Hall 202" },
      { code: "23CS102PC402", subject: "Natural Language Processing", date: "28.09.2026", session: "FN (09:30 AM - 12:30 PM)", time: "3 Hours", venue: "Academic Block B - Hall 204" }
    ]
  },
  {
    id: 2,
    name: "Priya Patel",
    rollNumber: "23CS102PE-089",
    branch: "Artificial Intelligence & Data Science",
    year: "3rd Year (B.Tech)",
    section: "AI-DS B",
    email: "priya.patel@scse.edu",
    attendance: 68, // Below 75% threshold -> triggers "Not Eligible" conditional rendering
    attendedClasses: 102,
    totalClasses: 150,
    hallTicketStatus: "Withheld (Attendance < 75%)",
    subjects: [
      { code: "23CS102PE405", name: "DevOps and Fullstack", instructor: "Mr. G. Kranthi", credits: 4, type: "Core" },
      { code: "23CS102PC401", name: "Deep Learning & Neural Networks", instructor: "Dr. N. Venkatesh", credits: 4, type: "Core" },
      { code: "23CS102PE412", name: "Big Data Analytics & Spark", instructor: "Dr. Mohammed Ali Shaik", credits: 3, type: "Elective" },
      { code: "23CS102PL403", name: "Fullstack Development Laboratory", instructor: "Mrs. Sri Vani", credits: 1.5, type: "Lab" }
    ],
    exams: [
      { code: "23CS102PE405", subject: "DevOps and Fullstack", date: "17.09.2026", session: "FN (09:30 AM - 12:30 PM)", time: "3 Hours", venue: "Academic Block C - Hall 101" },
      { code: "23CS102PC401", subject: "Deep Learning & Neural Networks", date: "21.09.2026", session: "FN (09:30 AM - 12:30 PM)", time: "3 Hours", venue: "Academic Block C - Hall 101" }
    ]
  },
  {
    id: 3,
    name: "Rohan Varma",
    rollNumber: "23CS102PE-114",
    branch: "Computer Science & Engineering",
    year: "3rd Year (B.Tech)",
    section: "CSE C",
    email: "rohan.varma@scse.edu",
    attendance: 93,
    attendedClasses: 140,
    totalClasses: 150,
    hallTicketStatus: "Issued",
    subjects: [
      { code: "23CS102PE405", name: "DevOps and Fullstack", instructor: "Dr. Mohammed Ali Shaik", credits: 4, type: "Core" },
      { code: "23CS102PC405", name: "Software Testing & Automation", instructor: "Mrs. Sri Vani", credits: 3, type: "Core" },
      { code: "23CS102PE415", name: "Cybersecurity & Cryptography", instructor: "Dr. N. Venkatesh", credits: 3, type: "Elective" },
      { code: "23CS102PL403", name: "Fullstack Development Laboratory", instructor: "Mr. G. Kranthi", credits: 1.5, type: "Lab" }
    ],
    exams: [
      { code: "23CS102PE405", subject: "DevOps and Fullstack", date: "17.09.2026", session: "FN (09:30 AM - 12:30 PM)", time: "3 Hours", venue: "Academic Block A - Hall 305" },
      { code: "23CS102PC405", subject: "Software Testing & Automation", date: "22.09.2026", session: "FN (09:30 AM - 12:30 PM)", time: "3 Hours", venue: "Academic Block A - Hall 305" }
    ]
  }
];

function App() {
  const [selectedStudent, setSelectedStudent] = useState(STUDENTS_DATA[0]);

  return (
    <div className="dashboard-app">
      {/* 1. Header Component */}
      <Header
        collegeName="School of Computer Science Engineering and Artificial Intelligence"
        appTitle="Student Management Dashboard"
        academicYear="2026-27"
        semester="ODD"
      />

      <main className="dashboard-main">
        {/* Bonus Challenge: StudentCard List with "View Profile" button to switch active student */}
        <section className="student-selector-section">
          <div className="section-heading-row">
            <div>
              <h2 className="section-title">👥 Student Directory (Bonus Challenge)</h2>
              <p className="section-hint">Click "View Profile" on any student to dynamically update dashboard props and check exam eligibility</p>
            </div>
          </div>
          <div className="student-card-grid">
            {STUDENTS_DATA.map((student) => (
              <StudentCard
                key={student.id}
                student={student}
                isSelected={selectedStudent.id === student.id}
                onSelect={(stu) => setSelectedStudent(stu)}
              />
            ))}
          </div>
        </section>

        {/* Dashboard Grid Row 1: Profile and Attendance */}
        <div className="dashboard-grid">
          {/* 2. StudentProfile Component (passes student details via props) */}
          <StudentProfile
            name={selectedStudent.name}
            rollNumber={selectedStudent.rollNumber}
            branch={selectedStudent.branch}
            year={selectedStudent.year}
            section={selectedStudent.section}
            email={selectedStudent.email}
          />

          {/* 3. Attendance Component (dynamic attendance & conditional eligibility) */}
          <Attendance
            percentage={selectedStudent.attendance}
            attendedClasses={selectedStudent.attendedClasses}
            totalClasses={selectedStudent.totalClasses}
          />
        </div>

        {/* Dashboard Grid Row 2: Subject List and Exam Details */}
        <div className="dashboard-grid">
          {/* 4. SubjectList Component (receives subjects array and renders with map) */}
          <SubjectList subjects={selectedStudent.subjects} />

          {/* 5. ExamDetails Component (receives examination information via props) */}
          <ExamDetails
            exams={selectedStudent.exams}
            hallTicketStatus={selectedStudent.hallTicketStatus}
            semester="ODD"
          />
        </div>
      </main>

      {/* 6. Footer Component */}
      <Footer />
    </div>
  );
}

export default App;
