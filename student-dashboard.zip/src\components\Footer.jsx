import React from 'react';

function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="dashboard-footer">
      <div className="footer-container">
        <p className="copyright-text">
          &copy; {currentYear} School of Computer Science Engineering and Artificial Intelligence. All Rights Reserved.
        </p>
        <p className="footer-subtext">
          Course: <strong>DEVOPS AND FULLSTACK (23CS102PE405)</strong> | Assignment 7.2.2: College Student Dashboard
        </p>
      </div>
    </footer>
  );
}

export default Footer;
