import React from 'react';

function ExamDetails({ exams = [], hallTicketStatus, semester = 'ODD' }) {
  return (
    <div className="card exam-details-card">
      <div className="card-header">
        <h2 className="card-title">📝 Examination Schedule</h2>
        <span className="card-tag">{semester} Semester 2026-27</span>
      </div>

      <div className="exam-meta-bar">
        <div>
          <strong>Hall Ticket Status: </strong>
          <span className={`badge ${hallTicketStatus === 'Issued' ? 'badge-primary' : 'badge-secondary'}`}>
            {hallTicketStatus || 'Under Review'}
          </span>
        </div>
        <div>
          <strong>Exam Mode: </strong>
          <span>Offline (Pen & Paper / Lab)</span>
        </div>
      </div>

      {exams.length === 0 ? (
        <p className="empty-notice">No exams currently scheduled.</p>
      ) : (
        <div className="exam-list">
          {exams.map((exam, index) => (
            <div key={index} className="exam-item">
              <div className="exam-date-badge">
                <span className="exam-date">{exam.date}</span>
                <span className="exam-session">{exam.session || 'FN'}</span>
              </div>
              <div className="exam-info">
                <h3 className="exam-subject">{exam.subject}</h3>
                <p className="exam-subtext">
                  Course Code: <span className="code-font">{exam.code}</span> | Time: {exam.time}
                </p>
                <p className="exam-venue">📍 Venue: {exam.venue || 'Block B, Hall 204'}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default ExamDetails;
