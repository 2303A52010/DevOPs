import React from 'react';

function StudentCard({ student, isSelected, onSelect }) {
  const isEligible = student.attendance >= 75;

  return (
    <div className={`student-card ${isSelected ? 'student-card-active' : ''}`}>
      <div className="student-card-top">
        <div className="student-card-avatar">
          {student.name.charAt(0).toUpperCase()}
        </div>
        <div className="student-card-info">
          <h4 className="student-card-name">{student.name}</h4>
          <p className="student-card-roll">{student.rollNumber}</p>
        </div>
      </div>

      <div className="student-card-details">
        <span className="student-card-branch">{student.branch}</span>
        {/* Conditional rendering for Eligibility in Card */}
        <span className={`badge ${isEligible ? 'badge-success' : 'badge-danger'}`}>
          {isEligible ? 'Eligible' : 'Not Eligible'} ({student.attendance}%)
        </span>
      </div>

      <button
        type="button"
        className={`btn-view-profile ${isSelected ? 'btn-selected' : ''}`}
        onClick={() => onSelect(student)}
      >
        {isSelected ? '✓ Viewing' : 'View Profile'}
      </button>
    </div>
  );
}

export default StudentCard;
