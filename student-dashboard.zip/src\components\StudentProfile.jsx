import React from 'react';

function StudentProfile({ name, rollNumber, branch, year, email, section }) {
  return (
    <div className="card student-profile-card">
      <div className="card-header">
        <h2 className="card-title">👤 Student Profile</h2>
        <span className="card-tag">Active Record</span>
      </div>
      <div className="profile-content">
        <div className="profile-avatar">
          {name ? name.charAt(0).toUpperCase() : 'S'}
        </div>
        <div className="profile-info-grid">
          <div className="info-item">
            <span className="info-label">Full Name</span>
            <span className="info-value highlight">{name || 'N/A'}</span>
          </div>
          <div className="info-item">
            <span className="info-label">Roll Number</span>
            <span className="info-value code-font">{rollNumber || 'N/A'}</span>
          </div>
          <div className="info-item">
            <span className="info-label">Branch / Department</span>
            <span className="info-value">{branch || 'N/A'}</span>
          </div>
          <div className="info-item">
            <span className="info-label">Academic Year</span>
            <span className="info-value">{year || 'N/A'}</span>
          </div>
          {section && (
            <div className="info-item">
              <span className="info-label">Section</span>
              <span className="info-value">{section}</span>
            </div>
          )}
          {email && (
            <div className="info-item">
              <span className="info-label">Email</span>
              <span className="info-value email-text">{email}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default StudentProfile;
