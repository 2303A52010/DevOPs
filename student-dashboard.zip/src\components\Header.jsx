import React from 'react';

function Header({ collegeName, appTitle, academicYear, semester }) {
  return (
    <header className="dashboard-header">
      <div className="header-container">
        <div className="header-branding">
          <div className="college-badge">🏛️ SCSE & AI</div>
          <div>
            <p className="college-name">{collegeName || "School of Computer Science Engineering and Artificial Intelligence"}</p>
            <h1 className="app-title">{appTitle || "Student Management Dashboard"}</h1>
          </div>
        </div>
        <div className="header-meta">
          <span className="badge badge-primary">Year: {academicYear || "2026-27"}</span>
          <span className="badge badge-secondary">Semester: {semester || "ODD"}</span>
          <span className="badge badge-info">Course: 23CS102PE405</span>
        </div>
      </div>
    </header>
  );
}

export default Header;
